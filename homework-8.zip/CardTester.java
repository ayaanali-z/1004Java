public class CardTester { 

	public static void main(String args[]) { 

		Card test = new Card(1, 4); 
		Card test2 = new Card(3, 12); 
		Card test3 = new Card(2, 10); 

		System.out.println(test); 
		System.out.println(test2); 
		System.out.println(test3); 

	}
}