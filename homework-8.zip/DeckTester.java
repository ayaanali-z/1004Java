import java.util.ArrayList; 
import java.util.Collections; 

public class DeckTester{
	public static void main(String args[]) { 
		Deck deckTest = new Deck(); 
		deckTest.shuffle(); 
		deckTest.returnDeck(); 
	}

}